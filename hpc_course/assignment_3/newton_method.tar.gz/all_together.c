#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <threads.h>
#include <complex.h>
#include <unistd.h>
#include <ctype.h>
#include <stdbool.h>

static const long double UPPER_BOUND = (1e10)*(1e10); //upper bound for deciding on divergence
static const float EPSILON_SQUARE = (1e-3)*(1e-3); //bound for convergence (stop iterations)
static const int CUTOFF = 100;

typedef struct {
  int val;
  char pad[60]; // cacheline - sizeof(int)
} int_padded;

typedef struct {
  int **attrs;
  int **iters;
  int ib;
  int istep;
  int nlines;
  int sz;
  int tx;
  int degree;
  mtx_t *mtx;
  cnd_t *cnd;
  int_padded *status;
  size_t *iterations;
  float complex *roots; 
} thrd_info_t;

typedef struct {
  int **attrs; 
  int **iters;
  int istep;
  int sz;
  int nthrds;
  int nlines;
  int degree;
  mtx_t *mtx;
  cnd_t *cnd;
  int_padded *status;
  FILE *attractor_file;
  FILE *iter_file;
} thrd_info_print_t;


static inline void newton_step(short unsigned int degree, size_t lines, size_t line, int *attr, int *iter, float complex *true_roots){

    float step = 4.f/(lines-1.f); 
    complex z2;
    complex z4;
    complex z8;
   
    switch (degree) {
       case 1:
	    for( int i=0; i<lines; i++){

		short int iteration = 0;
		bool stop= false;
		float complex z = (complex) (-2.) + (i*step) + (2 - line*step)*I;

		while(!stop){

		    float square_magnitude_real =  creal(z)*creal(z); 
		    float square_magnitude_im 	=  cimag(z)*cimag(z); 
		    float square_magnitude 	= square_magnitude_real + square_magnitude_im;

		    //greater than upper bound => stop working
		    if((square_magnitude_real >= UPPER_BOUND) || (square_magnitude_im >= UPPER_BOUND) ){
			attr[i] = degree;
			stop=true;
			break;
		    }

		    //too close to zero => stop working
		    if(square_magnitude <= EPSILON_SQUARE ){
			attr[i]= degree+1;
			stop=true;
			break;
		    }

		    //check if close enough to one of the real roots
		    //if it is => stop working
		    for( int j=0; j< degree; j++){
			
			float complex diff = (complex) (z - true_roots[j]);
			square_magnitude = creal(diff)*creal(diff) + cimag(diff)*cimag(diff);

			if(square_magnitude <= EPSILON_SQUARE){
			    attr[i]= j; //converges to the j-th root
			    stop=true;
			    break; 
			}
			
		    }

		    if(!stop){
		     // newton_step(&z, degree);
            		 z = 1.0;
		    }

		    iteration++;
		    
		}

		iter[i] = iteration < CUTOFF ? iteration : CUTOFF-1; // for iter file
	    }

            break;
        case 2:

	    for( int i=0; i<lines; i++){

		short int iteration = 0;
		bool stop= false;
		float complex z = (complex) (-2.) + (i*step) + (2 - line*step)*I;

		while(!stop){

		    float square_magnitude_real =  creal(z)*creal(z); 
		    float square_magnitude_im 	=  cimag(z)*cimag(z); 
		    float square_magnitude 	= square_magnitude_real + square_magnitude_im;

		    //greater than upper bound => stop working
		    if((square_magnitude_real >= UPPER_BOUND) || (square_magnitude_im >= UPPER_BOUND) ){
			attr[i] = degree;
			stop=true;
			break;
		    }

		    //too close to zero => stop working
		    if(square_magnitude <= EPSILON_SQUARE ){
			attr[i]= degree+1;
			stop=true;
			break;
		    }

		    //check if close enough to one of the real roots
		    //if it is => stop working
		    for( int j=0; j< degree; j++){
			
			float complex diff = (complex) (z - true_roots[j]);
			square_magnitude = creal(diff)*creal(diff) + cimag(diff)*cimag(diff);

			if(square_magnitude <= EPSILON_SQUARE){
			    attr[i]= j; //converges to the j-th root
			    stop=true;
			    break; 
			}
			
		    }

		    if(!stop){
		     // newton_step(&z, degree);
            	    	z = 0.5f* (1.f/z + z);
		    }

		    iteration++;
		    
		}

		iter[i] = iteration < CUTOFF ? iteration : CUTOFF-1; // for iter file
	    }

            break;
        case 3:

	    for( int i=0; i<lines; i++){

		short int iteration = 0;
		bool stop= false;
		float complex z = (complex) (-2.) + (i*step) + (2 - line*step)*I;

		while(!stop){

		    float square_magnitude_real =  creal(z)*creal(z); 
		    float square_magnitude_im 	=  cimag(z)*cimag(z); 
		    float square_magnitude 	= square_magnitude_real + square_magnitude_im;

		    //greater than upper bound => stop working
		    if((square_magnitude_real >= UPPER_BOUND) || (square_magnitude_im >= UPPER_BOUND) ){
			attr[i] = degree;
			stop=true;
			break;
		    }

		    //too close to zero => stop working
		    if(square_magnitude <= EPSILON_SQUARE ){
			attr[i]= degree+1;
			stop=true;
			break;
		    }

		    //check if close enough to one of the real roots
		    //if it is => stop working
		    for( int j=0; j< degree; j++){
			
			float complex diff = (complex) (z - true_roots[j]);
			square_magnitude = creal(diff)*creal(diff) + cimag(diff)*cimag(diff);

			if(square_magnitude <= EPSILON_SQUARE){
			    attr[i]= j; //converges to the j-th root
			    stop=true;
			    break; 
			}
			
		    }

		    if(!stop){
		     // newton_step(&z, degree);
            	  	 z = 1.f / (3.f * z * z) + (2.f * z) / 3.f;
		    }

		    iteration++;
		    
		}

		iter[i] = iteration < CUTOFF ? iteration : CUTOFF-1; // for iter file
	    }
            break;
        case 4:

	    for( int i=0; i<lines; i++){

		short int iteration = 0;
		bool stop= false;
		float complex z = (complex) (-2.) + (i*step) + (2 - line*step)*I;

		while(!stop){

		    float square_magnitude_real =  creal(z)*creal(z); 
		    float square_magnitude_im 	=  cimag(z)*cimag(z); 
		    float square_magnitude 	= square_magnitude_real + square_magnitude_im;

		    //greater than upper bound => stop working
		    if((square_magnitude_real >= UPPER_BOUND) || (square_magnitude_im >= UPPER_BOUND) ){
			attr[i] = degree;
			stop=true;
			break;
		    }

		    //too close to zero => stop working
		    if(square_magnitude <= EPSILON_SQUARE ){
			attr[i]= degree+1;
			stop=true;
			break;
		    }

		    //check if close enough to one of the real roots
		    //if it is => stop working
		    for( int j=0; j< degree; j++){
			
			float complex diff = (complex) (z - true_roots[j]);
			square_magnitude = creal(diff)*creal(diff) + cimag(diff)*cimag(diff);

			if(square_magnitude <= EPSILON_SQUARE){
			    attr[i]= j; //converges to the j-th root
			    stop=true;
			    break; 
			}
			
		    }

		    if(!stop){
		     // newton_step(&z, degree);
            		z = 1.f / (4.f * z * z * z) + (3.f * z) / 4.f;
		    }

		    iteration++;
		    
		}

		iter[i] = iteration < CUTOFF ? iteration : CUTOFF-1; // for iter file
	    }
            break;
        case 5:

	    for( int i=0; i<lines; i++){

		short int iteration = 0;
		bool stop= false;
		float complex z = (complex) (-2.) + (i*step) + (2 - line*step)*I;

		while(!stop){

		    float square_magnitude_real =  creal(z)*creal(z); 
		    float square_magnitude_im 	=  cimag(z)*cimag(z); 
		    float square_magnitude 	= square_magnitude_real + square_magnitude_im;

		    //greater than upper bound => stop working
		    if((square_magnitude_real >= UPPER_BOUND) || (square_magnitude_im >= UPPER_BOUND) ){
			attr[i] = degree;
			stop=true;
			break;
		    }

		    //too close to zero => stop working
		    if(square_magnitude <= EPSILON_SQUARE ){
			attr[i]= degree+1;
			stop=true;
			break;
		    }

		    //check if close enough to one of the real roots
		    //if it is => stop working
		    for( int j=0; j< degree; j++){
			
			float complex diff = (complex) (z - true_roots[j]);
			square_magnitude = creal(diff)*creal(diff) + cimag(diff)*cimag(diff);

			if(square_magnitude <= EPSILON_SQUARE){
			    attr[i]= j; //converges to the j-th root
			    stop=true;
			    break; 
			}
			
		    }

		    if(!stop){
			z2 = z * z;
		    	z = 1.f / (5.f * z2 * z2) + (4.f * z) / 5.f;
		    }

		    iteration++;
		    
		}

		iter[i] = iteration < CUTOFF ? iteration : CUTOFF-1; // for iter file
	    }
            break;
        case 6:

	    for( int i=0; i<lines; i++){

		short int iteration = 0;
		bool stop= false;
		float complex z = (complex) (-2.) + (i*step) + (2 - line*step)*I;

		while(!stop){

		    float square_magnitude_real =  creal(z)*creal(z); 
		    float square_magnitude_im 	=  cimag(z)*cimag(z); 
		    float square_magnitude 	= square_magnitude_real + square_magnitude_im;

		    //greater than upper bound => stop working
		    if((square_magnitude_real >= UPPER_BOUND) || (square_magnitude_im >= UPPER_BOUND) ){
			attr[i] = degree;
			stop=true;
			break;
		    }

		    //too close to zero => stop working
		    if(square_magnitude <= EPSILON_SQUARE ){
			attr[i]= degree+1;
			stop=true;
			break;
		    }

		    //check if close enough to one of the real roots
		    //if it is => stop working
		    for( int j=0; j< degree; j++){
			
			float complex diff = (complex) (z - true_roots[j]);
			square_magnitude = creal(diff)*creal(diff) + cimag(diff)*cimag(diff);

			if(square_magnitude <= EPSILON_SQUARE){
			    attr[i]= j; //converges to the j-th root
			    stop=true;
			    break; 
			}
			
		    }

		    if(!stop){
			 z2 = z * z;
			 z4 = z2 * z2;
			 z = 1.f / (6.f * z4 * z) + (5.f * z) / 6.f;
		    }

		    iteration++;
		    
		}

		iter[i] = iteration < CUTOFF ? iteration : CUTOFF-1; // for iter file
	    }
            break;
        case 7:

	    for( int i=0; i<lines; i++){

		short int iteration = 0;
		bool stop= false;
		float complex z = (complex) (-2.) + (i*step) + (2 - line*step)*I;

		while(!stop){

		    float square_magnitude_real =  creal(z)*creal(z); 
		    float square_magnitude_im 	=  cimag(z)*cimag(z); 
		    float square_magnitude 	= square_magnitude_real + square_magnitude_im;

		    //greater than upper bound => stop working
		    if((square_magnitude_real >= UPPER_BOUND) || (square_magnitude_im >= UPPER_BOUND) ){
			attr[i] = degree;
			stop=true;
			break;
		    }

		    //too close to zero => stop working
		    if(square_magnitude <= EPSILON_SQUARE ){
			attr[i]= degree+1;
			stop=true;
			break;
		    }

		    //check if close enough to one of the real roots
		    //if it is => stop working
		    for( int j=0; j< degree; j++){
			
			float complex diff = (complex) (z - true_roots[j]);
			square_magnitude = creal(diff)*creal(diff) + cimag(diff)*cimag(diff);

			if(square_magnitude <= EPSILON_SQUARE){
			    attr[i]= j; //converges to the j-th root
			    stop=true;
			    break; 
			}
			
		    }

		    if(!stop){
		     // newton_step(&z, degree);
		    z2 = z * z;
		    z4 = z2 * z2;
		    z = 1.f / (7.f * z4 * z2) + (6.f * z) / 7.f;
		    }

		    iteration++;
		    
		}

		iter[i] = iteration < CUTOFF ? iteration : CUTOFF-1; // for iter file
	    }
            break;
        case 8:

	    for( int i=0; i<lines; i++){

		short int iteration = 0;
		bool stop= false;
		float complex z = (complex) (-2.) + (i*step) + (2 - line*step)*I;

		while(!stop){

		    float square_magnitude_real =  creal(z)*creal(z); 
		    float square_magnitude_im 	=  cimag(z)*cimag(z); 
		    float square_magnitude 	= square_magnitude_real + square_magnitude_im;

		    //greater than upper bound => stop working
		    if((square_magnitude_real >= UPPER_BOUND) || (square_magnitude_im >= UPPER_BOUND) ){
			attr[i] = degree;
			stop=true;
			break;
		    }

		    //too close to zero => stop working
		    if(square_magnitude <= EPSILON_SQUARE ){
			attr[i]= degree+1;
			stop=true;
			break;
		    }

		    //check if close enough to one of the real roots
		    //if it is => stop working
		    for( int j=0; j< degree; j++){
			
			float complex diff = (complex) (z - true_roots[j]);
			square_magnitude = creal(diff)*creal(diff) + cimag(diff)*cimag(diff);

			if(square_magnitude <= EPSILON_SQUARE){
			    attr[i]= j; //converges to the j-th root
			    stop=true;
			    break; 
			}
			
		    }

		    if(!stop){
		     // newton_step(&z, degree);
		    z2 = z * z;
		    z4 = z2 * z2;
		    z = 1.f / (8.f * z4 * z2 * z) + (7.f * z) / 8.f;
		    }

		    iteration++;
		    
		}

		iter[i] = iteration < CUTOFF ? iteration : CUTOFF-1; // for iter file
	    }
            break;
        case 9:

	    for( int i=0; i<lines; i++){

		short int iteration = 0;
		bool stop= false;
		float complex z = (complex) (-2.) + (i*step) + (2 - line*step)*I;

		while(!stop){

		    float square_magnitude_real =  creal(z)*creal(z); 
		    float square_magnitude_im 	=  cimag(z)*cimag(z); 
		    float square_magnitude 	= square_magnitude_real + square_magnitude_im;

		    //greater than upper bound => stop working
		    if((square_magnitude_real >= UPPER_BOUND) || (square_magnitude_im >= UPPER_BOUND) ){
			attr[i] = degree;
			stop=true;
			break;
		    }

		    //too close to zero => stop working
		    if(square_magnitude <= EPSILON_SQUARE ){
			attr[i]= degree+1;
			stop=true;
			break;
		    }

		    //check if close enough to one of the real roots
		    //if it is => stop working
		    for( int j=0; j< degree; j++){
			
			float complex diff = (complex) (z - true_roots[j]);
			square_magnitude = creal(diff)*creal(diff) + cimag(diff)*cimag(diff);

			if(square_magnitude <= EPSILON_SQUARE){
			    attr[i]= j; //converges to the j-th root
			    stop=true;
			    break; 
			}
			
		    }

		    if(!stop){
		     // newton_step(&z, degree);
           		 z2 = z * z;
            		z4 = z2 * z2;
            		z = 1.f / (9.f * z4 * z4) + (8.f * z) / 9.f;
		    }

		    iteration++;
		    
		}

		iter[i] = iteration < CUTOFF ? iteration : CUTOFF-1; // for iter file
	    }
            break;
	case 10:

	    for( int i=0; i<lines; i++){

		short int iteration = 0;
		bool stop= false;
		float complex z = (complex) (-2.) + (i*step) + (2 - line*step)*I;

		while(!stop){

		    float square_magnitude_real =  creal(z)*creal(z); 
		    float square_magnitude_im 	=  cimag(z)*cimag(z); 
		    float square_magnitude 	= square_magnitude_real + square_magnitude_im;

		    //greater than upper bound => stop working
		    if((square_magnitude_real >= UPPER_BOUND) || (square_magnitude_im >= UPPER_BOUND) ){
			attr[i] = degree;
			stop=true;
			break;
		    }

		    //too close to zero => stop working
		    if(square_magnitude <= EPSILON_SQUARE ){
			attr[i]= degree+1;
			stop=true;
			break;
		    }

		    //check if close enough to one of the real roots
		    //if it is => stop working
		    for( int j=0; j< degree; j++){
			
			float complex diff = (complex) (z - true_roots[j]);
			square_magnitude = creal(diff)*creal(diff) + cimag(diff)*cimag(diff);

			if(square_magnitude <= EPSILON_SQUARE){
			    attr[i]= j; //converges to the j-th root
			    stop=true;
			    break; 
			}
			
		    }

		    if(!stop){
		     // newton_step(&z, degree);
		     	    z2 = z * z;
			    z4 = z2 * z2;
			    z8 = z4 * z4;
			    z = 1.f / (10.f * z8 * z) + (9.f * z) / 10.f;
			    
		    }

		    iteration++;
		    
		}

		iter[i] = iteration < CUTOFF ? iteration : CUTOFF-1; // for iter file
	    }
            break;
        default:
            fprintf(stderr, "unexpected degree\n");
            exit(1);
    }
}

/*

static inline void newton_computation(short unsigned int degree, size_t lines, size_t line, int *attr, int *iter, float complex *true_roots){


    float step = 4.f/(lines-1.f); 

    for( int i=0; i<lines; i++){

        short int iteration = 0;
        bool stop= false;
        float complex z = (complex) (-2.) + (i*step) + (2 - line*step)*I;

        while(!stop){

            float square_magnitude_real =  creal(z)*creal(z); 
	    float square_magnitude_im 	=  cimag(z)*cimag(z); 
	    float square_magnitude 	= square_magnitude_real + square_magnitude_im;

            //greater than upper bound => stop working
            if((square_magnitude_real >= UPPER_BOUND) || (square_magnitude_im >= UPPER_BOUND) ){
                attr[i] = degree;
                stop=true;
                break;
            }

            //too close to zero => stop working
            if(square_magnitude <= EPSILON_SQUARE ){
                attr[i]= degree+1;
                stop=true;
                break;
            }

            //check if close enough to one of the real roots
            //if it is => stop working
            for( int j=0; j< degree; j++){
                
                float complex diff = (complex) (z - true_roots[j]);
                square_magnitude = creal(diff)*creal(diff) + cimag(diff)*cimag(diff);

                if(square_magnitude <= EPSILON_SQUARE){
                    attr[i]= j; //converges to the j-th root
                    stop=true;
                    break; 
                }
                
            }

            if(!stop){
             // newton_step(&z, degree);
	    }

            iteration++;
            
        }

        iter[i] = iteration < CUTOFF ? iteration : CUTOFF-1; // for iter file
    }
}


*/


void writing_to_file(int d, size_t lines, int *attr, FILE *attractor_file, int *iter, FILE *iter_file){

    char color[lines*6+1];
    char no_color[lines*9+1];
    char ten;
    char one;

    for(int i=0; i<lines; i++) {
    
        //for attractor file
        color[6*i] = attr[i] +'0';
        color[6*i+1] = ' ';
        color[6*i+2] = (attr[i] + ((d+2)/3))% (d+2) +'0';
        color[6*i+3] = ' ';
        color[6*i+4] = (attr[i] + 2*((d+2)/3))% (d+2) +'0';
        color[6*i+5] = ' ';


        // for iter file
        if (iter[i] > 9) {
            ten = (iter[i] % 10) + '0';
            one = (iter[i] / 10) + '0';
            no_color[9*i] = ten;
            no_color[9*i+1] = one;
            no_color[9*i+2] = ' ';
            no_color[9*i+3] = ten;
            no_color[9*i+4] = one;
            no_color[9*i+5] = ' ';
            no_color[9*i+6] = ten;
            no_color[9*i+7] = one;
            no_color[9*i+8] = ' ';
        } else {
            one = (iter[i]) + '0';
            no_color[9*i] = one;
            no_color[9*i+1] = ' ';
            no_color[9*i+2] = ' ';
            no_color[9*i+3] = one;
            no_color[9*i+4] = ' ';
            no_color[9*i+5] = ' ';
            no_color[9*i+6] = one;
            no_color[9*i+7] = ' ';
            no_color[9*i+8] = ' ';
        }
        

    }

    color[lines*6] = '\n';
    no_color[lines*9] = '\n';

    fwrite(color, sizeof(char), lines*6+1, attractor_file); //write the whole line at once
    fwrite(no_color, sizeof(char), lines*9+1, iter_file); //write the whole line at once

}


int
main_thrd(
    void *args
    )
{
  const thrd_info_t *thrd_info = (thrd_info_t*) args;
  int **iters = thrd_info->iters;
  int **attrs = thrd_info->attrs; 
  const int ib = thrd_info->ib;
  const int istep = thrd_info->istep;
  int nlines = thrd_info->nlines; 
  const int tx = thrd_info->tx;
  const int degree = thrd_info->degree;
  mtx_t *mtx = thrd_info->mtx;
  cnd_t *cnd = thrd_info->cnd;
  int_padded *status = thrd_info->status;
  float complex *roots = thrd_info->roots;


  for ( int ix = ib; ix < nlines; ix += istep ) {
    newton_step(degree, nlines, ix, attrs[ix], iters[ix], roots);
    mtx_lock(mtx);
    status[tx].val = ix + istep;
    mtx_unlock(mtx);
    cnd_signal(cnd);
  } 

  return 0;
}

int
main_thrd_print(
    void *args
    )
{
  const thrd_info_print_t *thrd_info = (thrd_info_print_t*) args;
  int **attrs = thrd_info->attrs;
  int **iters = thrd_info->iters;   
  const int sz = thrd_info->sz;
  const int nthrds = thrd_info->nthrds;
  const int nlines = thrd_info->nlines;
  const int degree = thrd_info->degree;
  mtx_t *mtx = thrd_info->mtx;
  cnd_t *cnd = thrd_info->cnd;
  int_padded *status = thrd_info->status;
  FILE * attractor_file = thrd_info->attractor_file;
  FILE * iter_file = thrd_info->iter_file;


  for ( int ix = 0, ibnd; ix < nlines; ) {

    // If no new lines are available, we wait.
    for ( mtx_lock(mtx); ; ) {
      // We extract the minimum of all status variables.
      ibnd = sz;
      for ( int tx = 0; tx < nthrds; ++tx )
        if ( ibnd > status[tx].val )
          ibnd = status[tx].val;

      if ( ibnd <= ix )
        cnd_wait(cnd,mtx);
      else {
        mtx_unlock(mtx);
        break;
      }

    }
    for ( ; ix < ibnd; ++ix ) {
        writing_to_file(degree,nlines, attrs[ix], attractor_file, iters[ix], iter_file );
    }
  }

  return 0;
}

int
produce_images(const int nthrds, const int nlines, int degree, float complex *roots)
{
  const int sz = nlines*nlines;

  int * attrsentries = (int*) malloc(sizeof(int) * sz);
  int ** attrs = (int**) malloc(sizeof(int*) * nlines);

  int * itersentries = (int*) malloc(sizeof(int) * sz);
  int ** iters = (int**) malloc(sizeof(int*) * nlines);

  for ( size_t ix = 0, jx = 0; ix < nlines; ++ix, jx+=nlines )
  {
    attrs[ix] = attrsentries + jx;
    iters[ix] = itersentries + jx;
  }


  // Create file headers

  char attractor_file_name[25];
  char iter_file_name[26];
  sprintf(attractor_file_name, "newton_attractors_x%d.ppm", degree);
  sprintf(iter_file_name, "newton_convergence_x%d.ppm", degree);
  
  FILE *attractor_file = fopen(attractor_file_name, "w");
  FILE *iter_file = fopen(iter_file_name, "w");

  //attractor file
  fprintf(attractor_file, "P3\n");
  fprintf(attractor_file, "%d %d\n", nlines, nlines);
  fprintf(attractor_file, "%d\n", degree+2);

  //iter file
  fprintf(iter_file, "P3\n");
  fprintf(iter_file, "%d %d\n", nlines, nlines);
  fprintf(iter_file, "%d\n", degree+2);


  thrd_t thrds[nthrds];
  thrd_info_t thrds_info[nthrds];

  thrd_t thrd_print;
  thrd_info_print_t thrd_info_print;
  
  mtx_t mtx;
  mtx_init(&mtx, mtx_plain);

  cnd_t cnd;
  cnd_init(&cnd);

  int_padded status[nthrds];

  for ( int tx = 0; tx < nthrds; ++tx ) {
    thrds_info[tx].attrs = attrs;
    thrds_info[tx].iters = iters; 
    thrds_info[tx].ib = tx;
    thrds_info[tx].nlines = nlines; 
    thrds_info[tx].istep = nthrds;
    thrds_info[tx].sz = sz;
    thrds_info[tx].tx = tx;
    thrds_info[tx].degree = degree;
    thrds_info[tx].mtx = &mtx;
    thrds_info[tx].cnd = &cnd;
    thrds_info[tx].status = status;
    thrds_info[tx].roots = roots;
    status[tx].val = -1;

    int r = thrd_create(thrds+tx, main_thrd, (void*) (thrds_info+tx));
    if ( r != thrd_success ) {
      fprintf(stderr, "failed to create thread\n");
      exit(1);
    }
    thrd_detach(thrds[tx]);
  }

  {
    thrd_info_print.sz = sz;
    thrd_info_print.attrs = attrs;
    thrd_info_print.iters = iters;
    thrd_info_print.nlines = nlines;
    thrd_info_print.nthrds = nthrds;
    thrd_info_print.degree = degree;
    thrd_info_print.mtx = &mtx;
    thrd_info_print.cnd = &cnd;
    thrd_info_print.status = status;
    thrd_info_print.attractor_file = attractor_file;
    thrd_info_print.iter_file = iter_file;


    int r = thrd_create(&thrd_print, main_thrd_print, (void*) (&thrd_info_print));
    if ( r != thrd_success ) {
      fprintf(stderr, "failed to create thread\n");
      exit(1);
    }
  }

  {
    int r;
    thrd_join(thrd_print, &r);
  }

  free(attrsentries);
  free(attrs);
  free(itersentries);
  free(iters);

  mtx_destroy(&mtx);
  cnd_destroy(&cnd);
  
  fclose(attractor_file);
  fclose(iter_file);

  return 0;
}



int main(int argc, char **argv){
	int cmd_arg;
	int thrd_arg, line_arg; 
	short unsigned int degree_arg, other;

	while((cmd_arg = getopt(argc, argv, "t:l:"))!= -1){
		switch(cmd_arg){
			case 'l': line_arg=atoi(optarg); 
				  break;
			case 't': thrd_arg=atoi(optarg);
				  break;
			case '?':
                                    break;
			default:
				 fprintf(stderr, "could not proceees the arguments"); 
		}
	}
	
	other = atoi(argv[3]);		          
        if(other <= 10 && other > 0)  
            degree_arg = other;
	else
	    fprintf(stderr, "invalid degree");

	float complex true_roots[degree_arg];

    	for(int i=0; i<degree_arg; i++)
        	true_roots[i] = cexp(M_PI*2*i*I/degree_arg);

    	produce_images(thrd_arg, line_arg, degree_arg, true_roots);
    	return 0;
}
