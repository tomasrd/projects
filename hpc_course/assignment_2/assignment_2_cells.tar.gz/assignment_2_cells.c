#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <omp.h>
#include <unistd.h>

//constants
#define MAX_SIZE_READ 1000000   //read a a thousand points
#define MAX_DISTANCE 3465       //maximal distance between two points, as integer


#define SQUARE(r) r*r //use this macro to square a number


//define a structure to represent a point
typedef struct point {
    float x;
    float y;
    float z;
}point;


//the function computes the distance between any two points, and increment the appropriate index of the
//  array of distances. 
void calculate_distances_diagonal(
		long int *restrict distances,
		const point *restrict cells,
		const size_t iterations
		)
{
    #pragma omp parallel for reduction(+:distances[:MAX_DISTANCE])
    for (size_t pivot_index=0; pivot_index < iterations-1; pivot_index++){
        for(size_t running_index=pivot_index+1; running_index<iterations; running_index++){
            float x = cells[pivot_index].x - cells[running_index].x;
            float y = cells[pivot_index].y - cells[running_index].y;
            float z = cells[pivot_index].z - cells[running_index].z;
            distances[ (int) (100.f*sqrtf((SQUARE(x)+ SQUARE(y)+ SQUARE(z)))) ]++;
        }
    }
}

void calculate_distances_offdiagonal(
		long int *restrict distances,
		const point *restrict cells0,
		const size_t iterations0,
		const point *restrict cells1,
		const size_t iterations1
		)
{
    #pragma omp parallel for collapse(2) reduction(+:distances[:MAX_DISTANCE])
    for (size_t pivot_index=0; pivot_index < iterations0; pivot_index++){
        for(size_t running_index=0; running_index<iterations1; running_index++){
            float x = cells0[pivot_index].x - cells1[running_index].x;
            float y = cells0[pivot_index].y - cells1[running_index].y;
            float z = cells0[pivot_index].z - cells1[running_index].z;
            distances[ (int) (100.f*sqrtf((SQUARE(x)+ SQUARE(y)+ SQUARE(z)))) ]++;
        }
    }
}


int main(int argc, char *argv[]){    

    //parsing the command line argument
    int cmd_arg;
    cmd_arg = getopt(argc, argv, "t:");
    if(cmd_arg != 't') { fprintf(stderr, "invalid number of threads"); EXIT_FAILURE;} //quit in case of invalid argument
    unsigned short number_of_threads = atoi(optarg);
    omp_set_num_threads(number_of_threads);


    //open the file for reading. If can't, quit
    FILE *fp = fopen("cells", "r");
    if (fp == NULL){
	    printf("Could not open the file\n");
	    return EXIT_FAILURE;
    }

    //allocate a space for a million points
    point *cells0 = (point*) malloc(sizeof(point) * MAX_SIZE_READ);
    point *cells1 = (point*) malloc(sizeof(point) * MAX_SIZE_READ);

    //array for the distances and the occurrence of each one
    size_t distances[MAX_DISTANCE]={0};


    //count the number of lines in the file to determine how many points are there
	int ch;
	size_t num_of_points=0;
	do {
		ch= fgetc(fp);
		if (ch == '\n')
			num_of_points++;
	}while(ch != EOF);
    rewind(fp); //put the file pointer back to the beginning of the file


    //read every time min{MAX_SIZE_READ, number_of_points-counter}
    for ( size_t counter0=0, iterations0;  counter0 < num_of_points; counter0 += iterations0 ) {
        iterations0 = (counter0+MAX_SIZE_READ) <= num_of_points ? MAX_SIZE_READ : (num_of_points-counter0);

	fseek(fp, counter0 * 24, SEEK_SET);
        #pragma omp parallel for
        for(size_t i=0; i< iterations0; i++)
            fscanf(fp, "%f  %f  %f" , &cells0[i].x , &cells0[i].y, &cells0[i].z);

        //process the distances
        calculate_distances_diagonal(distances, cells0, iterations0);

        for ( size_t counter1=counter0+iterations0, iterations1;  counter1 < num_of_points; counter1 += iterations1 ) {
            iterations1 = (counter1+MAX_SIZE_READ) <= num_of_points ? MAX_SIZE_READ : (num_of_points-counter1);

            #pragma omp parallel for
            for(size_t i=0; i< iterations1; i++)
                fscanf(fp, "%f  %f  %f" , &cells1[i].x , &cells1[i].y, &cells1[i].z);
    
            //process the distances
            calculate_distances_offdiagonal(distances, cells0, iterations0, cells1, iterations1);
	}

    }
	
    fclose(fp);
    free(cells0);
    free(cells1);

    for(int i=0; i<MAX_DISTANCE; i++){
            printf("%05.2f %ld\n", i/100.f, distances[i]);
    }

    return EXIT_SUCCESS;
}
